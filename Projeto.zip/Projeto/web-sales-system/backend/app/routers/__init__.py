# File: /web-sales-system/web-sales-system/backend/app/routers/__init__.py

from fastapi import APIRouter

router = APIRouter()

from . import sales

router.include_router(sales.router, prefix="/sales", tags=["sales"])