# Web Sales System

This project is a web sales system that consists of a frontend built with HTML, CSS, and JavaScript, and a backend developed using FastAPI with SQLite as the database. The system allows users to manage products and orders through a user-friendly interface.

## Project Structure

```
web-sales-system
├── backend
│   ├── app
│   │   ├── main.py          # Entry point for the FastAPI application
│   │   ├── models.py        # SQLAlchemy models for the database
│   │   ├── schemas.py       # Pydantic schemas for request/response validation
│   │   ├── crud.py          # CRUD operations for products and orders
│   │   ├── database.py      # Database connection and session management
│   │   └── routers
│   │       ├── __init__.py  # Package initialization for routers
│   │       └── sales.py     # RESTful API endpoints for managing products and orders
│   ├── requirements.txt      # Dependencies for the backend
│   └── README.md             # Documentation for the backend
├── frontend
│   ├── index.html            # Main HTML file for the frontend
│   ├── css
│   │   └── styles.css        # Styles for the frontend
│   ├── js
│   │   └── app.js            # JavaScript code for handling interactions
│   └── README.md             # Documentation for the frontend
└── README.md                 # Overview of the entire project
```

## Getting Started

### Prerequisites

- Python 3.7 or higher
- Node.js (for frontend dependencies, if applicable)

### Backend Setup

1. Navigate to the `backend` directory.
2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the FastAPI application:
   ```
   uvicorn app.main:app --reload
   ```

### Frontend Setup

1. Navigate to the `frontend` directory.
2. Open `index.html` in your web browser to view the application.

## Usage

- The frontend allows users to view products, add them to a cart, and place orders.
- The backend provides a RESTful API for managing products and orders, which can be accessed via the frontend or tools like Postman.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any enhancements or bug fixes.

## License

This project is licensed under the MIT License.