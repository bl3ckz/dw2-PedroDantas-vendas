# Frontend Documentation for Web Sales System

## Overview
This is the frontend part of the Web Sales System project. It is built using HTML, CSS, and JavaScript, providing a user interface for interacting with the backend API.

## Project Structure
```
frontend
├── index.html       # Main HTML file for the application
├── css
│   └── styles.css   # Styles for the frontend
└── js
    └── app.js       # JavaScript for handling interactions
```

## Setup Instructions
1. Clone the repository:
   ```
   git clone <repository-url>
   ```
2. Navigate to the `frontend` directory:
   ```
   cd web-sales-system/frontend
   ```
3. Open `index.html` in your web browser to view the application.

## Usage
- The main page displays a product catalog where users can view available products.
- Users can add products to their cart and proceed to checkout.
- The application interacts with the backend API for CRUD operations on products and orders.

## Dependencies
- No external libraries are required for the frontend. All functionality is implemented using vanilla JavaScript, HTML, and CSS.