// This file contains the JavaScript code for handling interactions, including CRUD operations via fetch, localStorage management for the cart, and form validations.

document.addEventListener('DOMContentLoaded', () => {
    const productList = document.getElementById('product-list');
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    function fetchProducts() {
        fetch('/api/products')
            .then(response => response.json())
            .then(data => {
                productList.innerHTML = '';
                data.forEach(product => {
                    const productItem = document.createElement('div');
                    productItem.className = 'product-item';
                    productItem.innerHTML = `
                        <h3>${product.name}</h3>
                        <p>${product.description}</p>
                        <p>Price: $${product.price}</p>
                        <button onclick="addToCart(${product.id})">Add to Cart</button>
                    `;
                    productList.appendChild(productItem);
                });
            })
            .catch(error => console.error('Error fetching products:', error));
    }

    window.addToCart = function(productId) {
        const product = cart.find(item => item.id === productId);
        if (product) {
            product.quantity += 1;
        } else {
            cart.push({ id: productId, quantity: 1 });
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        alert('Product added to cart!');
    };

    function displayCart() {
        const cartModal = document.getElementById('cart-modal');
        cartModal.innerHTML = '';
        cart.forEach(item => {
            const cartItem = document.createElement('div');
            cartItem.innerHTML = `Product ID: ${item.id}, Quantity: ${item.quantity}`;
            cartModal.appendChild(cartItem);
        });
    }

    document.getElementById('view-cart').addEventListener('click', displayCart);

    fetchProducts();
});